package arreglos;
import arreglos.cConductor;
import java.util.ArrayList;
import java.util.*;


public class cArraylist {
    
    ArrayList <cConductor> conductor;
    
    public cArraylist(){
        
     
    }
    
    public void crearArraylist(){
        conductor = new ArrayList();
    }
    
    public void ingresarConductor(cConductor Conductor){
        conductor.add(Conductor);
    }
    
    public String devolverInformacion(){
        String reporte="";
        for(int contador=0;contador<conductor.size();contador++){
            
            reporte+=conductor.get(contador).toString()+"\n";
            
        }
        
        return reporte;
        
    }
    
}