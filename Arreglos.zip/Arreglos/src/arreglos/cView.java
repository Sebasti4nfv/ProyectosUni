
package arreglos;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.util.*;
import arreglos.cConductor;
import arreglos.cArraylist;


public class cView implements ActionListener {
    
    cArraylist arraylist;
    
    JFrame fRegister;
    
    JLabel lblTitulo,lblNombre,lblPlaca,lblNumeroCel,lblTipo;
    JTextField tfNombre,tfPlaca,tfNumeroCel,tfTipo;
    JButton btProcesar,btRegresar,btListar,btEliminar;
    JTextArea taListar;
    
    public cView(){
        
        //Option Pane Inicial
        String name;
        name = JOptionPane.showInputDialog("Ingrese su nombre: ");
        
        //Array
        arraylist = new cArraylist();
        arraylist.crearArraylist();
        
        //Frame
        fRegister = new JFrame();
        
        //Label
        lblTitulo = new JLabel("Registrar Conductor");
        lblTitulo.setBounds(200,10,120,90);
        
        lblNombre = new JLabel("Ingrese su nombre y apellido: ");
        lblNombre.setBounds(80,90,190,50);
        
        lblPlaca = new JLabel("Ingrese la placa de su vehiculo: ");
        lblPlaca.setBounds(80,140,190,50);
        
        lblNumeroCel = new JLabel("Ingrese su numero de celular: ");
        lblNumeroCel.setBounds(80, 190, 190, 50);
        
        lblTipo = new JLabel("Ingrese tipo del vehiculo: ");
        lblTipo.setBounds(80, 240, 190, 50);
        
        //Button
        btProcesar = new JButton("Procesar");
        btProcesar.setBounds(240,310,90,30);
        
        btRegresar = new JButton("Regresar");
        btRegresar.setBounds(240,380,90,30);
        
        btListar = new JButton("Listar");
        btListar.setBounds(380,380,80,30);
        
        btEliminar = new JButton("Eliminar");
        btEliminar.setBounds(100,380,80,30);
        
        //Text Field
        
        tfNombre = new JTextField();
        tfNombre.setBounds(300,95,100,30);
        
        tfPlaca = new JTextField();
        tfPlaca.setBounds(300,145,100,30);
        
        tfNumeroCel = new JTextField();
        tfNumeroCel.setBounds(300,195,100,30);
        
        tfTipo = new JTextField();
        tfTipo.setBounds(300,245,100,30);
        
        //text Area
        taListar = new JTextArea();
        taListar.setBounds(80, 450, 400, 200);
        taListar.setEditable(false);
        
        //Functions
        btProcesar.addActionListener(this);
        btRegresar.addActionListener(this);
        btListar.addActionListener(this);
        btEliminar.addActionListener(this);
        
        
        //Register Frame Adding
        fRegister.add(lblTitulo);
        fRegister.add(lblNombre);
        fRegister.add(lblPlaca);
        fRegister.add(lblNumeroCel);
        fRegister.add(lblTipo);
        fRegister.add(btProcesar);
        fRegister.add(btRegresar);
        fRegister.add(btListar);
        fRegister.add(btEliminar);
        fRegister.add(tfNombre);
        fRegister.add(tfPlaca);
        fRegister.add(tfNumeroCel);
        fRegister.add(tfTipo);
        fRegister.add(taListar);
        
        //Register Frame Charasteristics
        fRegister.setSize(600, 800);
        fRegister.setLayout(null);
        fRegister.setVisible(true);
        
        fRegister.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //List Frame
        /*
        fListar = new JFrame();
        fListar.setLayout(null);
        fListar.setSize(600,600);
        fListar.setVisible(false);
        */
        
        
        
    }
    
    public void actionPerformed(ActionEvent e){
        
        try{
            
            if(e.getSource()==btProcesar){
                
                String nombre = tfNombre.getText();
                
                String placa = tfPlaca.getText();
                
                String num =tfNumeroCel.getText();
                int numero =Integer.parseInt(num);
                
                String tipo = tfTipo.getText();
                
                
                cConductor conductor = new cConductor(nombre,placa,numero,tipo);
                arraylist.ingresarConductor(conductor);
                
                JOptionPane.showMessageDialog(null,"Informacion registrada");
                
            }
            
            if(e.getSource()==btRegresar){
                fRegister.setVisible(false);
                String name;
                name = JOptionPane.showInputDialog("Ingrese su nombre: ");
                
                
            }
            
            if(e.getSource()==btListar){
                
                taListar.setText("");
                taListar.setText(arraylist.devolverInformacion());
                
            }
            
        }catch(Exception ex){System.out.println("Error: "+ex.toString());}
    
    
    }
}

//Boton listar
