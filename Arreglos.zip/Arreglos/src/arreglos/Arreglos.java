
package arreglos;
import javax.swing.*;

public class Arreglos {

    
    public static void main(String[] args) {
        
        
        
        cView prueba = new cView();
        
        
    }
    
}
