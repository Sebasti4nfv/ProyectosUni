
package arreglos;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.util.*;

public class cConductor {
    
    private String nombre;
    private String placa;
    private int numCel;
    private String tipo;
    
    
    public cConductor(String nombre,String placa,int numCel,String tipo){
        this.nombre = nombre;
        this.placa = placa;
        this.numCel = numCel;
        this.tipo = tipo;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public String getPlaca(){
        return placa;
    }
    
    public void setPlaca(String placa){
        this.placa = placa;
    }
    
    public int getNumCel(){
        return numCel;
    }
    
    public void setNumCel(int numCel){
        this.numCel = numCel;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public void setTipo(String tipo){
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Listando Datos: " + "\n" + "Nombre: " + nombre + "\n" +"Placa: " + placa + "\n" + "Numero de celular: " + numCel + "\n" + "Tipo de vehiculo: " + tipo + "\n";
    }
    
    
    
}
