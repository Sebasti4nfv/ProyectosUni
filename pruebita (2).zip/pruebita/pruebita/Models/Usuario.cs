﻿using System;
using System.Collections.Generic;

namespace pruebita.Models
{
    public partial class Usuario
    {
        public string IdUsuario { get; set; } = null!;
        public string? NombreUsuario { get; set; }
        public string? ApellidoUsuario { get; set; }
        public int? EdadUsuario { get; set; }
        public string? NombreusuarioUsuario { get; set; }
        public string? CorreoUsuario { get; set; }
        public string? PasswordUsuario { get; set; }
        public string? IdTipoUsuario { get; set; }
    }
}
