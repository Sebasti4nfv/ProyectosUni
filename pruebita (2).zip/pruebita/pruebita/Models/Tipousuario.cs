﻿using System;
using System.Collections.Generic;

namespace pruebita.Models
{
    public partial class Tipousuario
    {
        public string IdTipoUsuario { get; set; } = null!;
        public string? Desc { get; set; }
    }
}
