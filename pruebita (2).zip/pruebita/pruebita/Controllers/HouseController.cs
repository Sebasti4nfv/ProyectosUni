﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using pruebita.Models;

namespace pruebita.Controllers
{
    public class HouseController : Controller
    {
        private readonly bdproyectoContext Context;

        public HouseController(bdproyectoContext Context)
        {
            this.Context = Context;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Validar(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                var Obj = (from TUsuario in Context.Usuarios where TUsuario.PasswordUsuario == usuario.PasswordUsuario && TUsuario.CorreoUsuario ==usuario.CorreoUsuario  select TUsuario).FirstOrDefault();

                if(Obj == null)
                {
                    
                    return RedirectToAction("Register");
                }
                else
                {
                    HttpContext.Session.SetString("susuario",JsonConvert.SerializeObject(Obj));
                    return RedirectToAction("Interfaz"); 
                }

            }
            else
            {
                return View("Register");
            }
        }

        public IActionResult Register()
        {
            
            return View();
        }

        public IActionResult RegisterUsuario(Usuario Obj)
        {
            if (ModelState.IsValid)
            {
                Context.Usuarios.Add(Obj);
                Context.SaveChanges();

                return RedirectToAction("Index");
            }
            else
            {
                
                return View("Register");
            }
        }

        public IActionResult Interfaz()
        {
            return View();
        }
    }

}
