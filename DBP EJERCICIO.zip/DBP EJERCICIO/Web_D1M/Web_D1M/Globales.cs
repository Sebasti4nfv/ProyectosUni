﻿
global using Web_D1M.Models;
global using Microsoft.EntityFrameworkCore;
