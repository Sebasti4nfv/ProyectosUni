﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
#nullable disable

namespace Web_D1M.Models
{
    public partial class NProfesor
    {
        public string IdProfesor { get; set; } = null!;
        public string? ProfPaterno { get; set; }
        public string? ProfMaterno { get; set; }
        public string? ProfNombres { get; set; }

        [Required(ErrorMessage ="Ingrese un USUARIO valido")]
        public string? ProfIdentificador { get; set; }
        
        [Required(ErrorMessage = "Ingrese un PASSWORD valido")]
        public string? ProfPassword { get; set; }
    }
}
