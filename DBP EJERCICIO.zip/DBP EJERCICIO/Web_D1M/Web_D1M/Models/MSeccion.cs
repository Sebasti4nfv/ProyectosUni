﻿using System;
using System.Collections.Generic;

namespace Web_D1M.Models
{
    public partial class MSeccion
    {
        public string IdSeccion { get; set; } = null!;
        public string? SecDescripcion { get; set; }
    }
}
