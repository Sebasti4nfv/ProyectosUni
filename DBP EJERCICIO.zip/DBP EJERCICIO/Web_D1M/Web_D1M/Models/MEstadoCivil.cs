﻿using System;
using System.Collections.Generic;

namespace Web_D1M.Models
{
    public partial class MEstadoCivil
    {
        public string IdEstadocivil { get; set; } = null!;
        public string? EstDescripcion { get; set; }
    }
}
