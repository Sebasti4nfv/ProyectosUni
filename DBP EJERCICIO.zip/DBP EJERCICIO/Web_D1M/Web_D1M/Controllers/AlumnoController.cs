﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Web_D1M.Controllers
{
    public class AlumnoController : Controller
    {
        //bdcolegioContext context = new bdcolegioContext();
        private readonly bdcolegioContext context;

        //constructor
        public AlumnoController(bdcolegioContext context)
        {
            this.context = context;
        }


        public IActionResult Index()
        {
            //obtener la sesion y lo almacena en el objeto session
            var ObjSesion = HttpContext.Session.GetString("sprofesor");
            if (ObjSesion != null)
            {
                var Obj = JsonConvert.DeserializeObject<NProfesor>
                    (HttpContext.Session.GetString("sprofesor"));
                ViewBag.usuario = Obj.ProfNombres + "" + Obj.ProfPaterno;
                var list = context.Alumnos;
                return View(list);
            }
            else
            { 
                return RedirectToAction("Index", "Profesor");
            }
        }

        public IActionResult Create()
        {
            //view bag recibe listas completas- estructura de datos dinamica
            ViewBag.Civil = context.MEstadoCivils;

            return View();
        }

        public IActionResult CreateAlumno(Alumno objAlu)
        {
            if (ModelState.IsValid)
            {
                //el objAlumno viene de los datos ingresados
                context.Alumnos.Add(objAlu);
                context.SaveChanges();

                return RedirectToAction("Index");
            }

            else
            {
                ViewBag.Civil = context.MEstadoCivils;
                return View("Create");
            }
        }

        /*ELIMINAR*/
        [Route("alumno/Delete/{Codigo}")]
        public IActionResult Delete(String Codigo)
        {
            //LINQ-LAMDBA :programar en SQL sin salir del programa
            var objAlu = (from Talu in context.Alumnos
                          where Talu.IdAlumno == Codigo /*where: filtro- condicion*/
                          select Talu).Single(); //single : muestra el registro que quier
            context.Alumnos.Remove(objAlu);
            context.SaveChanges(true); /*guardar cambios*/

            return RedirectToAction("Index");
        }

        //EDITAR
        [Route("alumno/Edit/{Codigo}")]
        public IActionResult Edit(string Codigo)
        {
            var objAlu = (from Talu in context.Alumnos
                          where Talu.IdAlumno == Codigo
                          select Talu).Single();

            //arreglo hash
            ViewData["id"] = objAlu.IdAlumno;
            ViewData["ape"] = objAlu.AluPaterno;
            ViewData["mat"] = objAlu.AluMaterno;
            ViewData["nom"] = objAlu.AluNombres;
            ViewData["sex"] = objAlu.AluSexo;
            ViewData["cod"] = objAlu.AluCodigo;
            ViewData["esc"] = objAlu.IdEstadocivil;
            ViewData["ema"] = objAlu.AluEmail;
            return View();

        }

        public IActionResult EditAlumno(Alumno objNew)
            {
            if (ModelState.IsValid)
            {

                var ObjOld = (from Talu in context.Alumnos
                              where Talu.IdAlumno == objNew.IdAlumno
                              select Talu).Single();

                ObjOld.AluPaterno = objNew.AluPaterno;
                ObjOld.AluMaterno = objNew.AluMaterno;
                ObjOld.AluNombres = objNew.AluNombres;
                ObjOld.AluSexo = objNew.AluSexo;
                ObjOld.AluCodigo = objNew.AluCodigo;
                ObjOld.IdEstadocivil = objNew.IdEstadocivil;
                ObjOld.AluEmail = objNew.AluEmail;

                context.SaveChanges(); //manda a la base de datos
                return RedirectToAction("Index");
            }

            else 
            { 
                return View("Edit"); 
            }
        }
    }
}
