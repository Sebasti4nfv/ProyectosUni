﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Web_D1M.Controllers
{
    public class ProfesorController : Controller
    {
        //bdcolegioContext context = new bdcolegioContext();
        private readonly bdcolegioContext context;

        //constructor
        public ProfesorController(bdcolegioContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Validar(NProfesor profesor)
        {
            if (ModelState.IsValid)
            {
                var ObjEncontrado =
                        (from TProfesor in context.NProfesors
                         where TProfesor.ProfIdentificador == profesor.ProfIdentificador &&
                         TProfesor.ProfPassword == profesor.ProfPassword
                         select TProfesor).FirstOrDefault();

                if (ObjEncontrado == null)
                {
                    return View("Index");
                }
                else
                {
                    //Crear la variable de session
                    HttpContext.Session.SetString("sprofesor", JsonConvert.SerializeObject(ObjEncontrado));
                    return RedirectToAction("Index", "Alumno");
                }
            }

            else
            {
                return View("Index");
            }
        }

        public IActionResult CerrarSesion()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Profesor");
        }
    }
}
