-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: bdcorp
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `n_profesor`
--

DROP TABLE IF EXISTS `n_profesor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `n_profesor` (
  `Id_profesor` char(6) NOT NULL,
  `prof_paterno` varchar(25) DEFAULT NULL,
  `prof_materno` varchar(25) DEFAULT NULL,
  `prof_nombres` varchar(35) DEFAULT NULL,
  `prof_identificador` varchar(20) DEFAULT NULL,
  `prof_password` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Id_profesor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `n_profesor`
--

LOCK TABLES `n_profesor` WRITE;
/*!40000 ALTER TABLE `n_profesor` DISABLE KEYS */;
INSERT INTO `n_profesor` VALUES ('000001','AGUINAGA','GALVEZ','Monica','vR5TUaRCDb','bXIFw9'),('000002','CALLOMA','ALDAVE','Patricia','hPSdu2rdmo','haQ6M7'),('000003','CEPEDA','MEDIANERO','Cesar','lCjOrCnhy2','I9X0rr'),('000004','CHAVARRY','VERA','Aracelly','GgBqahlIXx','DfQQO3'),('000005','DIAZ','YAFAC','Sara','WTLkOY5kIx','Xr9bZB'),('000006','GUSMAN','BRAVO','Luz','kJ3ZsraYlb','Fdrrdn'),('000007','ISLA','MONTANO','Karina','LlUTBqKwjG','CH87iE'),('000008','NUNTON','NUNEZ','Maureen','5quJia1eaQ','cReZF9'),('000009','PALMA','URCIA','Rosmery','erlJRmAotf','7mCKX6'),('000010','REYES','SALAZAR','Soledad','oXca2DDnaQ','mGWJfM'),('000011','VALVERDE','SANCHEZ','Mercedes','xoXOOEZ0Ra','e9bYVB'),('000012','AGURTO','SUNCION','Maybe','xMyvN9eNpQ','wI9Lfl'),('000013','ARBULU','AYALA','Guisella','HXbBInFi0d','SE1BGw'),('000014','CAMPOS','ABELLANEDA','Luis','AO3XgtuIIv','Zpdv6s'),('000015','CARBAJAL','IBERICO','Jesus','IbOE2YSatV','TVabao'),('000016','VALENCIA','LOPEZ','Julio','KwhRR1TwzP','nrc9gm'),('000017','CASTILLO','DURAND','Consuelo','bxqFR2Bcst','5a7Vzo'),('000018','CHAYAN','ALACHE','Martin','yXveD7MZ4k','Iz119T'),('000019','CHINCHAY','BANCES','Zarela','w46uVbngW9','bvwcG8'),('000020','SANCHEZ','TORO','Jadira','NJFMOOUKtI','wA7dGl'),('000021','CUEVA','CASTILLO','Judit','ks4YdbenER','RUWET8'),('000022','CUSTODIO','CHAFLOQUE','Cesar','lgy3WXtzGW','yyOsnu'),('000023','ESPINOZA','DAVILA','Flor','Rcowi3BHfc','YJ55hI'),('000024','ESPINOZA','SARMIENTO','Enrique','ibhZNrrO7Q','XXJJdM'),('000025','GONZALES','MORALES','Patricia','xz95BNawSp','0NDVMv'),('000026','GORDILLO','LLONTOP','Jaime','zPeJJphC6n','6gT1q3'),('000027','HUAMAN','MONTEZA','Vanessa','VSWLxPvvNb','lmExem'),('000028','INGA','HERRERA','Ingrid','v7bAVzQci7','heQEnZ'),('000029','LITANO','VASQUEZ','Victor','oO8sdy7AAP','A5op8X'),('000030','MARTINEZ','HOYOS','esgardo','RaIBazsW0T','KGcWwp'),('000031','MONTEZA','CISNEROS','Edgar','3NiLzsh8C6','sKZkL8'),('000032','SIESQUEN','SANDOVAL','Eva','Mc6DNzqsav','f54cFe'),('000033','SOLIS','BECERRA','Cesar','CQ7NQhmvcB','juDVim'),('000034','SOTO','FERNANDEZ','Sergio','fU9w6LQ6Pr','ZJHzxH'),('000035','VELASQUEZ','ESPINOZA','Carmen','hSUzxw77BV','ed6M64'),('000036','CASTANEDA','ALARCON','Marilu','PIKnzZ4lbN','t5isBK'),('000037','MATOS','SIRLOPU','Roxana','qwSU15b6p6','xiTPRx'),('000038','PERRIGO','RIMARACHIN','Laura','KNq1vR5TUa','RCDbbX'),('000039','SAMAME','HUEDA','Max','IFw9hPSdu2','rdmoha'),('000040','VEGA','PAZ','Antonio','Q6M7lCjOrC','nhy2I9'),('000041','VELASQUEZ','ESPINOZA','Victor','X0rrGgBqah','lIXxDf'),('000042','VILLANUEVA','YARLAQUE','Zenaida','QQO3WTLkOY','5kIxXr'),('000043','ALAMO','CHAPONAN','Adalberto','9bZBkJ3Zsr','aYlbFd'),('000044','ARENAS','ZEVALLOS','Luis','rrdnLlUTBq','KwjGCH'),('000045','BANCES','BRACO','Willian','87iE5quJia','1eaQcR'),('000046','BARBA','ALEGRIA','Cesar','eZF9erlJRm','Aotf7m'),('000047','BRAVO','BALAREZO','Ana','CKX6oXca2D','DnaQmG'),('000048','CACHAY','PEREZ','Tony','WJfMxoXOOE','Z0Rae9'),('000049','CAJAHUANCA','LOLI','Juan','bYVBxMyvN9','eNpQwI'),('000050','CAMPOS','ALARCON','Roger','9LflHXbBIn','Fi0dSE'),('000051','CARBONEL','CABRERA','Gustavo','1BGwAO3Xgt','uIIvZp'),('000052','CARRION','RODRIGUEZ','Edwin','dv6sIbOE2Y','SatVTV'),('000053','CASTILLO','RUEDA','Gladys','abaoKwhRR1','TwzPnr'),('000054','CHACON','GONZALES','Miguel','c9gmbxqFR2','Bcst5a'),('000055','CHIRINOS','RIOS','Cesar','7VzoyXveD7','MZ4kIz'),('000056','','','',' ',''),('000057','CHIRINOS','SANCHEZ','Jose','119Tw46uVb','ngW9bv'),('000058','CHANDUVI','QUISPE','Roger','wcG8NJFMOO','UKtIwA'),('000059','DEJO','AGUINAGA','Silvia','7dGlks4Ydb','enERRU'),('000060','DELGADO','WONG','Rosaura','WET8lgy3WX','tzGWyy'),('000061','ENRIQUEZ','VASQUEZ','Wilder','OsnuRcowi3','BHfcYJ'),('000062','LIZA','REQUE','Miguel','55hIibhZNr','rO7QXX'),('000063','FENCO','PERICHE','Beldad','JJdMxz95BN','awSp0N'),('000064','CHAVARRY','YSLA','Jose','DVMvzPeJJp','hC6n6g'),('000065','GIL','MONTERO','Jaime','T1q3VSWLxP','vvNblm'),('000066','HUAMANCHUMO','EFIO','Efrain','Exemv7bAVz','Qci7he'),('000067','LLONTOP','BRENIS','Carlos','QEnZoO8sdy','7AAPA5'),('000068','MACALOPU','RIMACHI','Jessica','Z5xQiYIiCm','6LyEzn'),('000069','MEJIA','PEREZ','Rosa','cWwp3NiLzs','h8C6sK'),('000070','MURILLO','CORNEJO','Luis','ZkL8Mc6DNz','qsavf5'),('000071','NEGREIROS','CHINCHIHUARA','Tatiana','4cFeCQ7NQh','mvcBju'),('000072','PASACHE','SAMILLAN','Jose','DVimfU9w6L','Q6PrZJ'),('000073','POZO','CABANILLAS','Jesica','HzxHhSUzxw','77BVed'),('000074','HIYANE','RAMIREZ','Mario','6M64PIKnzZ','4lbNt5'),('000075','ROSAS','QUINTANA','Mauricio','isBKIWdevT','8mCDm4'),('000076','SANCHEZ','DIAZ','Daniel','Tco05FEBQ3','WMH9hG'),('000077','MENDOZA','GRANADOS','Rudy','TzNV0dhhbM','K8XclY'),('000078','SIALER','RODRIGUEZ','Marleny','BnZUJXrBdr','862lDK'),('000079','YAMUNAQUE','CALLACNA','Omar','5l81IfDSOZ','cyGO2W'),('000080','SUXE','FERNANDEZ','Fisher','yF7NHEQOCv','QiuL1O'),('000081','TULLUME','GARNIQUE','Carlos','69P6ymf8wn','dAmEQV'),('000082','VALDEZ','ROMERO','Larry','swIBWwpjxX','POCCME'),('000083','VASQUEZ','HUATAY','Kely','pTLX5QhOiH','N1XSVB'),('000084','VIDAURRE','CHAVEZ','Jose','Wj49aEW8TC','DeieID'),('000085','FERNANDEZ','TORRES','Juan','uRMzG8ih1q','VRsBBU'),('000086','OLANO','LARREA','Edgar','OGhDmy4Z9M','8HkR9Y'),('000087','MATOS','CORAL','Bernardo','MeXdig4s6D','lgySXn'),('000088','ZUNIGA','AYALA','Miguel','Ik3SIfRF66','kj6v0u'),('000090','ALVAREZ','LECA','Karla','7YvNcRkW8K','JYRkiX'),('000091','RODRIGUEZ','MUNOZ','Miriam','DJxsQgx9Ow','HJU5gX'),('000092','DEZA','PEREYRA','Manuel Mariano','sSJfeYTPLp','gwVEig'),('000093','SANTINPERI','SANCHEZ','Jesica','yXs3fuCGy8','gb0UxZ'),('000094','NAZARIO','RUMICHE','Jose Demetrio','qwSU15b6p6xi','TPRxKNq1'),('000096','CABRERA','OLANO','Jose Felix','u2rdmohaQ6M7','lCjOrCnh'),('000097','FONSECA','SANCHEZ','Magno','y2I9X0rrGgBq','ahlIXxDf'),('000098','TORRES','LOZADA','Edgardo Jose','u2rdmohaQ6','M7lCjO'),('000099','DIAZ','PINILLOS','Armando','op8XRaIBaz','sW0TKG'),('000100','BENEL','CHAVEZ','Jhony','plBavlp0Xh','piGuMo'),('000102','CARRILLO','ATTO','Dina Elizabeth','6tgoOXYOwO','aXKU4G'),('000103','LAINA','JARA','Lucio Benjamin','KGnNBD2EKl','iXiGFC');
/*!40000 ALTER TABLE `n_profesor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-22  0:00:57
