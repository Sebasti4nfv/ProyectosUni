package ejerciciopc3;
import Controlador.ProductoController;

public class EjercicioPc3 {

    public static void main(String[] args)
    {
        ProductoController pCont = new ProductoController();
    }
}
