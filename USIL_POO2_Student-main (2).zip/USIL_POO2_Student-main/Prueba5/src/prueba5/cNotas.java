
package prueba5;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class cNotas implements ActionListener{
    
    JFrame f;
    JButton calcular;
    JTextField exFinal, exParcial, trabajoFinal,promedio,cantidad;
    JLabel lblFinal, lblParcial, lblTrabajo,lblCantidad;
    
    public cNotas(){
        
        f = new JFrame("Prueba");
        
        calcular = new JButton("Calcular");
        calcular.setBounds(400,100,90,30);
        
        exFinal = new JTextField();
        exFinal.setBounds(300,150,60,30);
        
        exParcial = new JTextField();
        exParcial.setBounds(300,200,60,30);
        
        trabajoFinal = new JTextField();
        trabajoFinal.setBounds(300,250,60,30);
        
        cantidad = new JTextField();
        cantidad.setBounds(300,100,60,30);
        
        lblFinal = new JLabel("Examen Final");
        lblFinal.setBounds(100,150,90,30);
        
        lblParcial = new JLabel("Examen Parcial");
        lblParcial.setBounds(100,200,90,30);
        
        lblTrabajo = new JLabel("Trabajo Final");
        lblTrabajo.setBounds(100,250,90,30);
        
        lblCantidad = new JLabel("Ingrese el numero de alumnos: ");
        lblCantidad.setBounds(100,100,180,30);
        
        promedio = new JTextField();
        promedio.setBounds(290,320,150,20);
        promedio.setEditable(false);
        
        calcular.addActionListener(this);
        
        f.add(calcular);
        f.add(exFinal);
        f.add(exParcial);
        f.add(trabajoFinal);
        f.add(lblFinal);
        f.add(lblParcial);
        f.add(lblTrabajo);
        f.add(promedio);
        
        
        
        f.setSize(600,600);
        f.setLayout(null);
        f.setVisible(true);
                    
        
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        
        
    }
     public void actionPerformed(ActionEvent e){
        
        try{
            
            
            String n1 = exFinal.getText();
            int nota1 = Integer.parseInt(n1);
            
            String n2 = exParcial.getText();
            int nota2 = Integer.parseInt(n2);
            
            String n3 = trabajoFinal.getText();
            int nota3 = Integer.parseInt(n3);
            
            double prom = 0;
            
            if(e.getSource()== calcular){
                
                prom = ((nota1*0.55) + (nota2*0.30) + (nota3*0.15));
                
                
            }
            String result=String.valueOf(prom);
            promedio.setText(result);
            
            
        }catch(Exception ex){System.out.println("Error: "+ex.toString());}
        
        
        
    }
    
    
    
}
