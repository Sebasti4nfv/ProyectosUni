package ejerciciotaxi;

public class EjercicioTaxi
{
    public static void main(String[] args)
    {
        Interfaz interfaz = new Interfaz();
    }
    
}
