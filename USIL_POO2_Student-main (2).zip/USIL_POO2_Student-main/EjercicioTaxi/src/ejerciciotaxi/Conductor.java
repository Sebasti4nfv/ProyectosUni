package ejerciciotaxi;

public class Conductor
{
    String codConductor;
    String nombreConductor;
    String placaVehiculo;
    String numeroCelular;
    String tipoVehiculo;
    
    public Conductor()
    {
        this.codConductor = "";
        this.nombreConductor = "";
        this.placaVehiculo = "";
        this.numeroCelular = "";
        this.tipoVehiculo = "";
    }
}
