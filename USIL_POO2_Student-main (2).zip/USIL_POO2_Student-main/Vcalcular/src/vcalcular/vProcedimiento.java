/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vcalcular;

import java.awt.Color;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class vProcedimiento extends WindowAdapter implements ActionListener {
    
    JFrame f;
    JLabel l;
    JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,bClear,bsuma,bresta,bmulti,bdivi,bresultado;
    JTextField ta;
    
    
    
    public vProcedimiento(){
        
        f = new JFrame("CALCULADORA");
      
        
        l = new JLabel("Calculadora casera");
        l.setBounds(30, 5, 200, 20);
        
        ta = new JTextField ("");
        ta.setBounds(30, 30, 300, 30);
        
        b1 = new JButton("1");
        b1.setBounds(30, 75, 50, 50);
        b1.addActionListener(this);
        b2 = new JButton("2");
        b2.setBounds(30, 125, 50, 50);
        b2.addActionListener(this);
        b3 = new JButton("3");
        b3.setBounds(30, 175, 50, 50);
        b3.addActionListener(this);
        b4 = new JButton("4");
        b4.setBounds(80, 75, 50, 50);
        b4.addActionListener(this);
        b5 = new JButton("5");
        b5.setBounds(80, 125, 50, 50);
        b5.addActionListener(this);
        b6 = new JButton("6");
        b6.setBounds(80, 175, 50, 50);
        b6.addActionListener(this);
        b7 = new JButton("7");
        b7.setBounds(130, 75, 50, 50);
        b7.addActionListener(this);
        b8 = new JButton("8");
        b8.setBounds(130, 125, 50, 50);
        b8.addActionListener(this);
        b9 = new JButton("9");
        b9.setBounds(130, 175, 50, 50);
        b9.addActionListener(this);
        b0 = new JButton("0");
        b0.setBounds(130, 225, 50, 50);
        b0.addActionListener(this);
        
        bClear = new JButton("Clear");
        bClear.setBounds(30, 225, 100, 50);
        bClear.addActionListener(this);
        bsuma = new JButton("+");
        bsuma.setBounds(200, 75, 50, 50);
        bsuma.addActionListener(this);
        bresta = new JButton("-");
        bresta.setBounds(200, 125, 50, 50);
        bresta.addActionListener(this);
        bmulti = new JButton("x");
        bmulti.setBounds(200, 175, 50, 50);
        bmulti.addActionListener(this);
        bdivi = new JButton("/");
        bdivi.setBounds(200, 225, 50, 50);
        bdivi.addActionListener(this);
        bresultado = new JButton("=");
        bresultado.setBounds(200, 290, 50, 50);
        bresultado.addActionListener(this);
        
    
        f.add(l);
        f.add(b1);
        f.add(b2);
        f.add(b3);
        f.add(b4);
        f.add(b5);
        f.add(b6);
        f.add(b7);
        f.add(b8);
        f.add(b9);
        f.add(b0);
        f.add(bClear);
        f.add(bsuma);
        f.add(bresta);
        f.add(bmulti);
        f.add(bdivi);
        f.add(ta);
        f.add(bresultado);
        
        f.setSize(400, 400);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.addWindowListener(this);
    }    
        
    public void actionPerformed (ActionEvent e)
    {
         try{
    
        }catch (Exception ex){System.out.println("Error" + ex.toString());}
    }  
    
   public void windowClosing(WindowEvent e){
        int valor = JOptionPane.showConfirmDialog(f, "Estas seguro que quieres salir?");
        
        if(valor == JOptionPane.YES_OPTION){
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
    } 
    
}
