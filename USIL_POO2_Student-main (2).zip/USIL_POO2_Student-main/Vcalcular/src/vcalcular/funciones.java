/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vcalcular;


public class funciones {
    
 int n1,n2,n3,n4,n4,n5,n6,n7,n8,n9,n0;
 
 
 public int Suma()
 {
 
 
 
 
 
 }
 
}
