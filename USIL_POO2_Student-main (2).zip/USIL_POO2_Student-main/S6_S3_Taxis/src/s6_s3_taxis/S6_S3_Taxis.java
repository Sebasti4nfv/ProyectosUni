/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package s6_s3_taxis;

/**
 *
 * @author alumnoc2laba70504
 */
public class S6_S3_Taxis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Interfaz obj=new Interfaz();
    }
    
}
