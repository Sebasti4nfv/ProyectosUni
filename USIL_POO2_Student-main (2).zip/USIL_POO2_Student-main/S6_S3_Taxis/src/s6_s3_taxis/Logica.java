/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package s6_s3_taxis;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author alumnoc2laba70504
 */
public class Logica {
    int CodConductor;
    String NombreConductor;
    String Placa;
    int Numero;
    String Tipo;

    public Logica(int CodConductor, String NombreConductor, String Placa, int Numero, String Tipo) {
        this.CodConductor = CodConductor;
        this.NombreConductor = NombreConductor;
        this.Placa = Placa;
        this.Numero = Numero;
        this.Tipo = Tipo;
    }
    
    public String Agregar(ArrayList<Conductor> lista){
        Conductor codnu= new Conductor(CodConductor, NombreConductor, Placa, Numero, Tipo);
        lista.add(codnu);
        return "Se agrego a la lista";
    }
    public String Listar( ArrayList<Conductor> lista){
        String agregado;
        String cons="";
        Iterator itr =lista.iterator();
        //Recopilar informacion de conductores
        for(int i=1; lista.size()>=i; i++){
            Conductor Conduc=(Conductor)itr.next();
            agregado="-El conductor "+i+"\n °Codigo: "+Conduc.CodConductor+"\n °Nombre: "+Conduc.NombreConductor+"\n °Placa: "+Conduc.Placa+"\n °Numero de celular: "+Conduc.Numero+"\n °Tipo de vehiculo: "+Conduc.Tipo+"\n";
            cons=cons+agregado;
        }
        return cons;
    }
    /*
    public String Eliminar(String Nom, ArrayList<Conductor> lista){
        int removido=0;
        String envio="";
        ArrayList<Integer> listIndices=new ArrayList<>();
        Iterator itr =lista.iterator();
        for(int i=0; i<lista.size(); i++){
            Conductor Conduc=(Conductor)itr.next();
            //Obtener los indices de los conductores que tienen los nombres
            if(Conduc.NombreConductor.equals(Nom)){
                listIndices.add(i);
                removido++;
                envio="Se removio a todos los conductores con el nombre "+Nom+" ("+removido+")";
            }
        }
        int cons=listIndices.size()-1;
        //Remover valores de la lista
        for(int i=cons; i>=0; i--){
            int a=listIndices.get(i);
            lista.remove(a);
        }
        if (removido==0){
            envio="No se encontro el nombre del conductor";
        }
        return envio;
    }
    
    
    Funcion eliminar(Solo eliminaba 1 si es que habia mas de una coincidencia
    */
    public String Eliminar(String Nom, ArrayList<Conductor> lista){
        int removido=0;
        String envio="";
        Iterator itr =lista.iterator();

        for(int i=0; i<lista.size(); i++){
            Conductor Conduc=(Conductor)itr.next();
            if(Conduc.NombreConductor.equals(Nom)){
                lista.remove(i);
                removido++;
                envio="Se removio";
            }
        }
        if (removido==0){
            envio="No se encontro el nombre del conductor";
        }
        return envio;
    }
    
    
    /*
    Funcion que evita insertar mas de una vez a un conductor con el mismo nombre 
    */
    public int Comparar(String nomn, ArrayList<Conductor> lista, Logica abc){
        Iterator itr =lista.iterator();
        int valor=0;
        for (Conductor lista1 : lista) {
            Conductor Conduc=(Conductor)itr.next();
            if(Conduc.NombreConductor.equals(nomn)){
                valor++;
                
            }
        }
        return valor;
    }
}
