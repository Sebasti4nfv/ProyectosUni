/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package s6_s3_taxis;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author alumnoc2laba70504
 */
public class Interfaz implements ActionListener{
    JFrame f;
    JButton bEliminar, bRegistrar, bListar;
    JTextField tfCodigo, tfNombre, tfPlaca, tfNumero;
    JComboBox cbTipoDeVehiculo;
    JLabel lCod, lNombre, lPlaca, lNumero, lTipo;
    Logica logic;
    String Tipos[]= {"Sedan","SUV"};
    ArrayList<Conductor> newConductor=new ArrayList<>();
    public Interfaz(){
        f=new JFrame("Taxis");
        //Botones
        bEliminar=new JButton("Eliminar");
        bRegistrar = new JButton("Registrar");
        bListar=new JButton("Listar");
        bEliminar.setBounds(25, 210, 100, 30);
        bRegistrar.setBounds(130, 210, 100, 30);
        bListar.setBounds(235, 210, 100, 30);
        bEliminar.setActionCommand("Eliminar");
        bRegistrar.setActionCommand("Registrar");
        bListar.setActionCommand("Listar");
        bEliminar.addActionListener(this);
        bRegistrar.addActionListener(this);
        bListar.addActionListener(this);
        //TextField
        tfCodigo=new JTextField();
        tfNombre=new JTextField();
        tfPlaca=new JTextField();
        tfNumero=new JTextField();
        tfCodigo.setBounds(160, 25, 100, 30);
        tfNombre.setBounds(160, 60, 100, 30);
        tfPlaca.setBounds(160, 95, 100, 30);
        tfNumero.setBounds(160, 130, 100, 30);
        //ComboBox
        cbTipoDeVehiculo=new JComboBox(Tipos);
        cbTipoDeVehiculo.setBounds(160, 165, 100, 30);
        //Label
        lCod=new JLabel("Codigo: ");
        lNombre=new JLabel("Nombre: ");
        lPlaca=new JLabel("Placa: ");
        lNumero=new JLabel("Numero de telefono: "); 
        lTipo=new JLabel("Tipo de Vehiculo: ");
        lCod.setBounds(25, 25, 100, 30);
        lNombre.setBounds(25, 60, 100, 30);
        lPlaca.setBounds(25, 95, 100, 30); 
        lNumero.setBounds(25, 130, 125, 30);
        lTipo.setBounds(25, 165, 125, 30);
        //Añadir elementos
        f.add(lCod);
        f.add(lNombre);
        f.add(lPlaca);
        f.add(lNumero);
        f.add(lTipo);
        f.add(bEliminar);
        f.add(bRegistrar);
        f.add(bListar);
        f.add(cbTipoDeVehiculo);
        f.add(tfCodigo);
        f.add(tfNombre);
        f.add(tfPlaca);
        f.add(tfNumero);
        
        f.setSize(370, 320);
        f.setLayout(null);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    //Limpiar TextField
    public void clearAll(){
        tfCodigo.setText("");
        tfNombre.setText("");
        tfPlaca.setText("");
        tfNumero.setText("");
    }
    public void actionPerformed(ActionEvent e) {
        int cod=Integer.parseInt(tfCodigo.getText());
        String nombre=tfNombre.getText();
        String placa=tfPlaca.getText();
        int numero=Integer.parseInt(tfNumero.getText());
        String tipo=(String) cbTipoDeVehiculo.getSelectedItem();
        //Identificar que boton se esta activando
        if ("Eliminar".equals(e.getActionCommand())) {
            String nombreElim;
            nombreElim=JOptionPane.showInputDialog(f, "Ingresa el nombre a eliminar: ");
            JOptionPane.showMessageDialog(f, logic.Eliminar(nombreElim, newConductor));
            
        }else if ("Registrar".equals(e.getActionCommand())) {
            logic=new Logica(cod, nombre, placa, numero, tipo);
            /*
            Condicion para uso con Comparar, avisar al usuario que ese nombre ya fue registrado
            */
            if(logic.Comparar(nombre,newConductor, logic)==0){
                JOptionPane.showMessageDialog(null, logic.Agregar(newConductor));
                
            }else{
                JOptionPane.showMessageDialog(null, "Ya se encuentra este conductor en la lista");

            }/*
            JOptionPane.showMessageDialog(null, logic.Agregar(newConductor));
            
            clearAll();*/
            
            
        }else if("Listar".equals(e.getActionCommand())) {
            JOptionPane.showMessageDialog(null, logic.Listar(newConductor));
        }
        
    }
}
