/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package s6_s3_taxis;

/**
 *
 * @author alumnoc2laba70504
 */
public class Conductor {
    int CodConductor;
    String NombreConductor;
    String Placa;
    int Numero;
    String Tipo;

    public Conductor(int CodConductor, String NombreConductor, String Placa, int Numero, String Tipo) {
        this.CodConductor = CodConductor;
        this.NombreConductor = NombreConductor;
        this.Placa = Placa;
        this.Numero = Numero;
        this.Tipo = Tipo;
    }

    public int getCodConductor() {
        return CodConductor;
    }

    public void setCodConductor(int CodConductor) {
        this.CodConductor = CodConductor;
    }

    public String getNombreConductor() {
        return NombreConductor;
    }

    public void setNombreConductor(String NombreConductor) {
        this.NombreConductor = NombreConductor;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }

    public int getNumero() {
        return Numero;
    }

    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
}
