package exoregistrotaxi;

import java.util.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class Interfaz implements ActionListener
{
    JFrame frame;
    JLabel lblTitulo, lblCod, lblNom, lblPlaca, lblNumC, lblTipo;
    JTextField tfCod, tfNom,tfPlaca,tfNumC,tfTipo;
    JButton btnRegistrar, btnListar, btnEliminar;
    ArrayList<Taxi> arrayConductores = new ArrayList<>();
    
    
    public Interfaz()
    {
        //Se crea el frame
        frame = new JFrame("Registro");
        
        lblTitulo = new JLabel("Registrar Conductor");
        lblTitulo.setBounds(110,20,150,20);
        
        //Labels y TextFields del formulario
        lblCod = new JLabel("Codigo:");
        lblCod.setBounds(125,70,100,20);
        tfCod = new JTextField();
        tfCod.setBounds(200,70,80,20);
        
        lblNom = new JLabel("Nombre:");
        lblNom.setBounds(120,110,100,20);
        tfNom = new JTextField();
        tfNom.setBounds(200,110,80,20);
        
        lblNumC = new JLabel("Número de celular:");
        lblNumC.setBounds(60,150,150,20);
        tfNumC = new JTextField();
        tfNumC.setBounds(200,150,80,20);
        
        lblPlaca = new JLabel("Placa del Vehículo:");
        lblPlaca.setBounds(60,190,150,20);
        tfPlaca = new JTextField();
        tfPlaca.setBounds(200,190,80,20);
        
        lblTipo = new JLabel("Tipo de vehículo (Sedan/SUV):");
        lblTipo.setBounds(20,230,190,20);
        tfTipo = new JTextField();
        tfTipo.setBounds(200,230,80,20);
        
        //Botones
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(120,280,90,20);
        btnRegistrar.addActionListener(this);
        
        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(30,280,80,20);
        btnEliminar.addActionListener(this);
        
        btnListar = new JButton("Listar");
        btnListar.setBounds(220,280,80,20);
        btnListar.addActionListener(this);
        
        //Agregando elementos al frame
        frame.add(lblTitulo);
        frame.add(lblCod);
        frame.add(tfCod);
        frame.add(lblNom);
        frame.add(tfNom);
        frame.add(lblNumC);
        frame.add(tfNumC);
        frame.add(lblPlaca);
        frame.add(tfPlaca);
        frame.add(lblTipo);
        frame.add(tfTipo);
        frame.add(btnRegistrar);
        frame.add(btnEliminar);
        frame.add(btnListar);
        
        //Config del frame
        frame.setSize(350,400);
        frame.setLayout(null);
        frame.setVisible(true);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public void actionPerformed(ActionEvent e)
    {
        try 
        {
            //Cuando el usuario hace click en Registrar
            if(e.getSource() == btnRegistrar)
            {
                //Se recuperan los datos ingresados en el formulario
                String cod = tfCod.getText();
                String nom = tfNom.getText();
                String numCel = tfNumC.getText();
                String placa = tfPlaca.getText();
                String tipo = tfTipo.getText();
                
                Taxi objConductor = new Taxi(cod,nom,numCel,placa,tipo); //Creación del obj de la clase Taxi

                arrayConductores.add(objConductor); //Se añade el obj al array

                //Se limpian los campos para un nuevo registro
                tfCod.setText("");
                tfNom.setText("");
                tfNumC.setText("");
                tfPlaca.setText("");
                tfTipo.setText("");
            }
            //Cuando el usuario hace click en Listar
            if(e.getSource() == btnListar)
            {
                //Creación de otro frame para mostrar los resultados
                JFrame frameListar = new JFrame("Listar conductores");
                JTextArea txtA = new JTextArea(); 
                txtA.setBounds(10,10,310,540);
                
                //Creación del obj de la clase Taxi
                Taxi objConductor = new Taxi(); 
                String resultado = objConductor.getListaConductores(arrayConductores);//Se llama a la funcion Listar de la clase Taxi

                //Resultado se pinta en el TextArea
                txtA.setText(resultado); 
                frameListar.add(txtA);
                frameListar.setSize(350,600);
                frameListar.setLayout(null);
                frameListar.setVisible(true);
                
            }
            //Cuando el usuario hace click en Eliminar
            if(e.getSource() == btnEliminar)
            {
                //Creación del obj de la clase Taxi
                Taxi objConductor = new Taxi();  
                
                //JOptionPane con input para recuperar el nombre
                String nombre = JOptionPane.showInputDialog(frame,"Ingrese el nombre del conductor: "); 
                //Nuevo frame
                JFrame frameResultados = new JFrame("Resultados");
                //TextArea en donde se mostrarán las posibles coincidencias
                JTextArea txtA = new JTextArea(); 
                txtA.setBounds(10,70,330,440); 
                
                JLabel lbl = new JLabel("Ingrese el codigo del conductor que desea eliminar:");
                lbl.setBounds(10,10,300,20);
                lbl.setVisible(false);
                JTextField tf = new JTextField();
                tf.setBounds(320,10,80,20);
                tf.setVisible(false);
                
                JButton btnRemove = new JButton("Eliminar");
                btnRemove.setBounds(180,45,100,20);
                btnRemove.setVisible(false);
                
                //Obtencion de los conductores con el mismo nombre con el método de la clase Taxi
                String resultado = objConductor.getCoincidenciasNom(arrayConductores, nombre);
                if(resultado.equals(""))
                {
                    resultado += "No se encontraron resultados"; //Se muestra si no se encontró ninguna coincidencia
                    txtA.setText(resultado);
                }
                else
                {
                    lbl.setVisible(true); //Si se encontraron coincidencias se habilita la opción para ingresar un codigo, el tf y el boton
                    tf.setVisible(true);
                    btnRemove.setVisible(true);
                    txtA.setText(resultado);
                    btnRemove.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            String codigo = tf.getText(); //Se recupera el codigo ingresado
                            objConductor.eliminarCond(arrayConductores, codigo);//Se llama a la función eliminar de la clase Taxi
                            JOptionPane.showMessageDialog(frameResultados, "Se eliminó al conductor","Atención",JOptionPane.WARNING_MESSAGE);
                            frameResultados.dispose(); //Se cierra la ventana
                            
                        }
                    });
                }

                frameResultados.add(txtA);
                frameResultados.add(lbl);
                frameResultados.add(tf);
                frameResultados.add(btnRemove);
                
                frameResultados.setSize(450,600);
                frameResultados.setLayout(null);
                frameResultados.setVisible(true);
            }
            
        } 
        catch (Exception ex) 
        {
            System.out.println("Error: "+ex.toString());
        }
    }

}
