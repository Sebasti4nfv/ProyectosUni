package exoregistrotaxi;


public class ExoRegistroTaxi {


    public static void main(String[] args) {
        Interfaz obj = new Interfaz();
        
    }
    
}
