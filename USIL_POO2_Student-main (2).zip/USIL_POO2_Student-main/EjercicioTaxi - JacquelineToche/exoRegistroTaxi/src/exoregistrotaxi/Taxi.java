/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exoregistrotaxi;

import java.util.*;

/**
 *
 * @author Jacquie
 */
public class Taxi {
    
    String codConductor;
    String nomConductor;
    String placaVehiculo;
    String numCelular;
    String tipoVehiculo;

    public Taxi(String codConductor, String nomConductor, String placaVehiculo, String numCelular, String tipoVehiculo) {
        this.codConductor = codConductor;
        this.nomConductor = nomConductor;
        this.placaVehiculo = placaVehiculo;
        this.numCelular = numCelular;
        this.tipoVehiculo = tipoVehiculo;
    }

    public Taxi() {
    }

    //Se obtienen todos los elementos del array
    public String getListaConductores(ArrayList<Taxi> arrayConductores)
    {
        String resultado = "";
        for (int i = 0; i < arrayConductores.size(); i++) 
        {
            //Por cada objeto en el array se recuperan sus propiedades y se concatenan en el String resultado
            resultado += "Conductor " + String.valueOf(i + 1) + "\n";
            resultado += "Codigo: " + arrayConductores.get(i).codConductor + "\n" + "Nombre: " + arrayConductores.get(i).nomConductor
                    + "\n" + "Celular: " + arrayConductores.get(i).numCelular + "\n" + "Placa: " + arrayConductores.get(i).placaVehiculo + "\n"
                    + "Tipo de vehículo: " + arrayConductores.get(i).tipoVehiculo + "\n" + "\n";

        }
        return resultado;
    }
    
    //Buscar conductores con el mismo nombre
    public String getCoincidenciasNom(ArrayList<Taxi> arrayConductores,String nombre) 
    {
        String resultado = "";
        for (Taxi x : arrayConductores) {
            //Se busca en el array todos los conductores con el nombre que se ingresó en el JOptionPane
            if (x.nomConductor.equalsIgnoreCase(nombre)) {
                //Si coincide, se concatenan sus datos en "resultado"
                resultado += "Codigo: " + x.codConductor + "\n" + "Nombre: " + x.nomConductor
                        + "\n" + "Celular: " + x.numCelular + "\n" + "Placa: " + x.placaVehiculo + "\n"
                        + "Tipo de vehículo: " + x.tipoVehiculo + "\n" + "\n";
            }

        }

        return resultado;
    }
    
    //Se elimina el conductor seleccionado del array
    public void eliminarCond( ArrayList<Taxi> arrayConductores, String codigo)
    {
        int index = 0;
        Iterator itrTaxi = arrayConductores.iterator();
        while (itrTaxi.hasNext()) 
        {
            Taxi cond = (Taxi) itrTaxi.next();
            if (cond.codConductor.equals(codigo)) //Se busca el conductor comparando los codigos en cada elemento del array
            {
                index = arrayConductores.indexOf(cond); //Cuando se encuentra se guarda el index
            }
        }

        arrayConductores.remove(index);
    }
    
}
