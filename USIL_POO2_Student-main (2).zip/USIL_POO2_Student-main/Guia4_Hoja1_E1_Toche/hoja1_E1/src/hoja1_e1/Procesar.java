/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hoja1_e1;


public class Procesar {
       
    int precio;
    
    public Procesar(){}

    public int getPrecio() {
        return precio;
    }
       
    
    public void calcularPrecioLP(String fab, String tipo, String dispo)
    {

        if(fab.equals("Microsoft"))
        {
            if(dispo.equals("Celular"))
            {
                precio =1800;
            }
            else if(dispo.equals("Tabla"))
            {
                precio = 1200;
            }
            else if(dispo.equals("Otros"))
            {
                precio = 900;
            }
            
        }
        else if(fab.equals("Apple"))
        {
            if(dispo.equals("Celular"))
            {
                precio = 1900;
            }
            else if(dispo.equals("Tabla"))
            {
                precio = 1800;
            }
            else if(dispo.equals("Otros"))
            {
                precio = 1600;
            }
        }
        else if(fab.equals("Linux"))
        {
            if(dispo.equals("Celular"))
            {
                precio = 100;
            }
            else if(dispo.equals("Tabla"))
            {
                precio = 150;
            }
            else if(dispo.equals("Otros"))
            {
                precio = 50;
            }
        }
    }
    public void calcularPrecioSO(String fab, String tipo)
    {

        if(fab.equals("Microsoft"))
        {
            precio = 1500;
            
        }
        else if(fab.equals("Apple"))
        {
            precio = 2500;
        }
        else if(fab.equals("Linux"))
        {
            precio = 1000;
        }
    }
}
