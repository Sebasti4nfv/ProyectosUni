/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hoja1_e1;

/*Una empresa de software tiene planificado comprar programas para el desarrollo de
aplicaciones móviles. El costo es variable según el fabricante elegido. También deberá
elegir el tipo de programa y si es Lenguaje de Programación debe elegir el dispositivo
(Celulares, Tablas y Otros)
*/
/*Se le pide elaborar un programa en JAVA que permita determinar el costo total por la
compra del programa elegido si se tienen como datos el fabricante (M: Microsoft; A: 
Apple; L: Linux), el tipo de programa (S: Sistema operativo; L: Lenguaje de 
programación) y el dispositivo (C: Celular; T: Tabla; O: Otros).
*/
public class Hoja1_E1 {

    public static void main(String[] args) {
        Interfaz objInter = new Interfaz();
    }
    
}
