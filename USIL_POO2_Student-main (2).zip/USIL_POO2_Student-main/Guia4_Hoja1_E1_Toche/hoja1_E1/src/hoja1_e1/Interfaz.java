/*Se le pide elaborar un programa en JAVA que permita determinar el costo total por la
compra del programa elegido si se tienen como datos el fabricante (M: Microsoft; A: 
Apple; L: Linux), el tipo de programa (S: Sistema operativo; L: Lenguaje de 
programación) y el dispositivo (C: Celular; T: Tabla; O: Otros).
*/
package hoja1_e1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class Interfaz implements ActionListener {
    
    JLabel lblTlo,lbl1, lbl2,lbl3;
    JButton btnProcesar;
    JComboBox<Object> cbFabric;
    JComboBox<Object> cbTipo;
    JComboBox<Object> cbDispos;
    JFrame frame;
    
    public Interfaz()
    {
        frame = new JFrame("Ejercicio 1");
        
        lblTlo = new JLabel("Determinar costo total");
        lblTlo.setBounds(90, 15, 180, 20);
        
        btnProcesar = new JButton("Procesar");
        btnProcesar.setBounds(110, 190, 110, 20);        
        btnProcesar.addActionListener(this);
        
        lbl1 = new JLabel("Fabricante:");
        lbl1.setBounds(50, 60, 100, 20);        
        String fabricante[]={"Microsoft","Apple","Linux"};
        cbFabric = new JComboBox(fabricante);
        cbFabric.setBounds(180, 60, 120, 20);
        
        lbl3 = new JLabel("Dispositivo:");
        lbl3.setBounds(50, 140, 150, 20);
        lbl3.setVisible(false);
        String dispositivos[] = {"Celular", "Tabla", "Otros"};
        cbDispos = new JComboBox(dispositivos);
        cbDispos.setBounds(180, 140, 120, 20);
        cbDispos.setVisible(false);
               
        lbl2 = new JLabel("Tipo de programa:");
        lbl2.setBounds(50, 100, 150, 20);
        String tipo[]={"Sistema Operativo","Lenguaje de Programación"};
        cbTipo = new JComboBox(tipo);
        cbTipo.setBounds(180, 100, 120, 20);
        cbTipo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) 
            {
                String tip = cbTipo.getSelectedItem().toString();
                if (tip.equals("Lenguaje de Programación")) {
                    
                    lbl3.setVisible(true);
                    cbDispos.setVisible(true);
                    
                }
            }
        });
        
        frame.add(lblTlo);
        frame.add(lbl1);
        frame.add(cbFabric);
        frame.add(lbl2);
        frame.add(cbTipo);        
        frame.add(lbl3);
        frame.add(cbDispos);
        frame.add(btnProcesar);
         
        frame.setSize(350,400);
        frame.setLayout(null);
        frame.setVisible(true);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public void actionPerformed(ActionEvent e)
    {
        try 
        {           
            
            String fab = cbFabric.getSelectedItem().toString();
            String tip = cbTipo.getSelectedItem().toString();
            
            if(tip.equals("Sistema Operativo"))
            {
                Procesar obj = new Procesar();
                obj.calcularPrecioSO(fab, tip);
                JOptionPane.showMessageDialog(frame, "El precio total es: "+obj.getPrecio());
            }
            else if(tip.equals("Lenguaje de Programación"))
            {
                String disp = cbDispos.getSelectedItem().toString();
                Procesar obj = new Procesar();
                obj.calcularPrecioLP(fab, tip, disp);
                JOptionPane.showMessageDialog(frame, "El precio total es: "+obj.getPrecio());
            }
            
            
  
        } catch (Exception ex) 
        {
            System.out.println("Error:"+ex.toString());
        }
    }
    
}
