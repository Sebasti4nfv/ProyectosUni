
package porfa.funciona;
import static java.lang.System.in;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class PorfaFunciona {

   
    public static void main(String[] args) {
        ArrayList<Integer> vectorEnteros = new ArrayList<Integer>();
        
        Scanner in = new Scanner(System.in);
        int a = 0;
        System.out.println("Ingrese la cantidad de numeros que desea usar(max 50)");
         a = in.nextInt();
         
         System.out.println("Listado:");
        for(int i = 0; i < a; i++){
            vectorEnteros.add(ThreadLocalRandom.current().nextInt(0, 50 + 1));
        }

        for(int i = 0; i < vectorEnteros.size(); i++) {
            if (i == vectorEnteros.size() - 1) {
                System.out.println(vectorEnteros.get(i) + " ");
            }else if (vectorEnteros.get(i) <= vectorEnteros.get(i + 1)) {
                System.out.print(vectorEnteros.get(i) + " ");
            } else {
                System.out.println(vectorEnteros.get(i));
            }
        }
        
      
        
    }
    
}
