package com.example.pruebatf.Controller;

import com.example.pruebatf.Model.Usuario;

import java.util.ArrayList;

public class UsuarioController {
    private ArrayList<Usuario> lstUsuario;

    public UsuarioController()
    {
        lstUsuario = new ArrayList<>();
    }
    public void add (Usuario objusuario)
    {
        lstUsuario.add(objusuario);
    }
    public Usuario get(int pos)
    {
        return lstUsuario.get(pos);
    }
    public int size()
    {
        return lstUsuario.size();
    }
}
