package com.example.pruebatf.Model;

public class Usuario {
    private String IdUsuario;
    private String NombreUsuario;
    private String ApellidoUsuario;
    private String NombreUsuarioUsuario;
    private String Contraseña;

    public Usuario() {
    }

    public Usuario(String idUsuario, String nombreUsuario, String apellidoUsuario, String nombreUsuarioUsuario, String contraseña) {
        IdUsuario = idUsuario;
        NombreUsuario = nombreUsuario;
        ApellidoUsuario = apellidoUsuario;
        NombreUsuarioUsuario = nombreUsuarioUsuario;
        Contraseña = contraseña;
    }

    public String getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        IdUsuario = idUsuario;
    }

    public String getNombreUsuario() {
        return NombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        NombreUsuario = nombreUsuario;
    }

    public String getApellidoUsuario() {
        return ApellidoUsuario;
    }

    public void setApellidoUsuario(String apellidoUsuario) {
        ApellidoUsuario = apellidoUsuario;
    }

    public String getNombreUsuarioUsuario() {
        return NombreUsuarioUsuario;
    }

    public void setNombreUsuarioUsuario(String nombreUsuarioUsuario) {
        NombreUsuarioUsuario = nombreUsuarioUsuario;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String contraseña) {
        Contraseña = contraseña;
    }
}
