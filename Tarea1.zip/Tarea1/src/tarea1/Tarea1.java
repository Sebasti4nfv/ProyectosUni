
package tarea1;

import javax.swing.*;
public class Tarea1 {

        
    public static void main(String[] args) {
   
     
       cVisual c = new cVisual();
    }
    
}
