# TrabajoFinal1.0
Trabajo Final del Grupo 12
## Integrantes:
- Jose Alonso Lozada Bazan
- Dayana Sophia Paz Alejos
- Juan Carlos Ayala Segundo
- Sebastian Javier Fonseca Vicente
- Fabio Enzo Liendo Lanchi
