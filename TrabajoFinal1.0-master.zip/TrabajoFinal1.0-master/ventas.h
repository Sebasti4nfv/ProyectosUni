//
// Created by jalb2 on 07/06/2022.
//

#ifndef TRABAJOFINAL2_VENTAS_H
#define TRABAJOFINAL2_VENTAS_H

#include <iostream>
#include "varios.h"
#include "ropa.h"
#include "electronico.h"

using namespace std;

class Ventas{
};
#endif //TRABAJOFINAL2_VENTAS_H
